

    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="./style/style.css">
</head>
<body>                                                              <!--Body start-->
    <div class="main">                                              <!--Main part start-->
    <?php
include "sidebar.php";

?>

                                                         <!--Sidebar End-->




        
        <div class="content">                                                          <!--Content start-->
            <div class="mainContent container-fluid pt-5 pb-3">                                                                                   <div class="p-3 mb-2 bg-white text-dark">Teacher Appointment</div>             
                <div class="col-lg-4 col-md-6 pb-1">
                    <div class="profile-list">
                        
                                  <?php
                                 		 require "connection.php";
     $query0 = "SELECT * FROM `teacher_applicant`";
        $data0 = mysqli_query($con, $query0);
        $total0=mysqli_num_rows($data0)>0;
        
        if($total0){
            while($romin0=mysqli_fetch_array($data0)){
               		$applicant_id=$romin0['applicant_id'];
			$job_id=$romin0['job_id'];
			$app_name=$romin0['app_name'];
			$app_phone=$romin0['app_phone'];
				$app_payment_method=$romin0['app_payment_method'];
			$tk_sender_phone=$romin0['tk_sender_phone'];
			$email=$romin0['email'];
			?>
			  <a style="text-decoration:none;" href="totalapplicantlist.php">
                        <div class="profile-card">
                          
                            <p>Enroll ID : <?php echo 	$applicant_id; ?><br/>
                                  Job ID : <?php echo 	$job_id; ?><br/>
                                  
                                      Subject : <?php 
                                      if($job_id=='1'){
                                          echo "Bangla";
                                      }elseif($job_id=='2'){
                                          echo "English";
                                      }elseif($job_id=='3'){
                                          echo "Math";
                                      }elseif($job_id=='4'){
                                          echo "Religion";
                                      }elseif($job_id=='5'){
                                          echo "General";
                                      }
                                      ?></p>
                                 
                                  <h3> <?php echo 	$app_name; ?></h3>
                                  
                                   <p> Phone : <?php echo 	$app_phone; ?><br/>
                                      Payment Method : <?php echo 	$app_payment_method; ?><br/>
                                             Payment Number : <?php echo 	$tk_sender_phone; ?><br/>
                                                   Email : <?php echo 	$email; ?></p>
                                       
                         
                        </div>
                        </a>
			<?php
          
            }
?>
<?php
   }
?>
                        
                 
                  
                        
                        
                        
                    
                    </div>
                </div>  
                                                 
            </div>               
        </div>    <!--Content End-->









    </div> <!--Main part End--> 
    
    
</body>                                                                <!--Body part End-->
</html>
    
    
    
