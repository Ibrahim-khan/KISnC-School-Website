
<div class="d-flex flex-column align-items-center p-3 bg-light" style="width: 100%; max-width: 300px;"> <!-- Sidebar Start -->
  <div class="text-center mb-4"> <!-- Profile Start -->
    <img src="./image/3333.jpg" class="rounded-circle" alt="Profile Picture" width="120" height="120">
    <h2 class="mt-2">Admin Dashboard</h2>
    <p>Kachakata Ideal School & College</p>
	</div>

	<div> <!-- Menu Bar Start -->
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" href="#">General Account</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Appointment</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Applicant List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Share Holder List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Management</a>
      </li>
    </ul>
  </div> <!-- Menu Bar End -->
</div> <!-- Sidebar End -->
