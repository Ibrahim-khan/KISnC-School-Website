<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="./style/style.css">
</head>
<body>                                                             
    <div class="log-in">
        <div class="login-form">
            <form action="dashboard.php" method="post">
                <h4 style="background-color: aqua; width: fit-content; padding: 5px;">Log In</h4><br/>
                <input type="text" id="username" name="email" placeholder="Insert Email Address"/><br/>
                   <br />
                <input type="password" id="password" name="password" placeholder="Type Here Password">
                  <br />
                     <br />
                  <button type="submit">Submit</button> 
                 
            </form> 
                                                  
        </div>
    </div>                                                         
</body>                                                              
</html>