<?php
$localhost ="localhost";
$user ="root";
$pass ="";
$dbname ="kisnc";
$con= mysqli_connect($localhost, $user, $pass, $dbname);
if ($con)
{
	echo "";
}	
	 else 
			echo "Not Connected!";
		
	
?>