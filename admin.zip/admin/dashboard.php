<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <?php include "sidebar.php"; ?> <!-- Sidebar End -->
      </div>

      <div class="col-md-9">
        <div class="row">
          <!-- Total Applications Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="./image/12341.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Total Applications</h5>
                  <p class="card-text">
                    <?php
                      require "connection.php";
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt`";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>

          <!-- Application in Bangla Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="./image/bng.jpeg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Application in Bangla</h5>
                  <p class="card-text">
                    <?php
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt` WHERE job_id=1";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>
		  
		  <!-- Application in English Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="https://www.aitong.moe.edu.sg/images/ATS_English.jpeg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Application in English</h5>
                  <p class="card-text">
                    <?php
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt` WHERE job_id=1";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>
		  
		  <!-- Application in Mathematics Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="./image/math.jpeg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Application in Mathematics</h5>
                  <p class="card-text">
                    <?php
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt` WHERE job_id=1";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>
		  
		  
		  <!-- Application in Religion Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="./image/islam.jpg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Application in Religion</h5>
                  <p class="card-text">
                    <?php
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt` WHERE job_id=1";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>
		  
		  <!-- Application in General Card -->
          <div class="col-md-4 mb-3">
            <a href="totalapplicantlist.php" class="text-decoration-none">
              <div class="card h-100 text-center">
                <img src="./image/general.jpeg" class="card-img-top rounded-circle mx-auto mt-3" alt="picture" style="width: 80px; height: 80px;">
                <div class="card-body">
                  <h5 class="card-title">Application in General</h5>
                  <p class="card-text">
                    <?php
                      $query = "SELECT COUNT(applicant_id) as totalchamber FROM `teacher_applicantt` WHERE job_id=1";
                      $data = mysqli_query($con, $query);
                      if (mysqli_num_rows($data) > 0) {
                        $romin = mysqli_fetch_array($data);
                        echo $romin['totalchamber'];
                      }
                    ?>
                  </p>
                </div>
              </div>
            </a>
          </div>		            
        </div>
      </div> <!-- Content End -->
    </div> <!-- Row End -->
  </div> <!-- Main Part End -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
